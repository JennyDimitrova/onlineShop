package onlineShop.models.products.computers;

import onlineShop.models.products.BaseProduct;
import onlineShop.models.products.Product;
import onlineShop.models.products.components.Component;
import onlineShop.models.products.peripherals.Peripheral;

import java.util.ArrayList;
import java.util.List;

public abstract class BaseComputer extends BaseProduct implements Computer {
    private List<Component> components;
    private List<Peripheral> peripherals;

    protected BaseComputer(int id, String manufacturer, String model, double price, double overallPerformance) {
        super(id, manufacturer, model, price, overallPerformance);
        this.components = new ArrayList<>();
        this.peripherals = new ArrayList<>();
    }

    @Override
    public List<Component> getComponents() {
        return components;
    }

    @Override
    public List<Peripheral> getPeripherals() {
        return peripherals;
    }

    @Override
    public double getOverallPerformance() {

        if (this.components.isEmpty()) {
            return super.getOverallPerformance();
        }
        double sum = super.getOverallPerformance();
        double averageOfPeripherals = this.peripherals.stream().mapToDouble(Product::getOverallPerformance).average().orElse(0.00);
        sum += averageOfPeripherals;
        return sum;
    }

    @Override
    public double getPrice() {
        double sumOfComponents = this.components.stream().mapToDouble(Product::getPrice).sum();
        double sumOfPeripherals = this.peripherals.stream().mapToDouble(Product::getPrice).sum();
        double totalSum = super.getPrice() + sumOfComponents + sumOfPeripherals;
        return totalSum;
    }

    @Override
    public void addComponent(Component component) {
        for (Component component2 : this.components) {
            if (component2.getClass().getSimpleName().equals(component.getClass().getSimpleName())) {
                throw new IllegalArgumentException(
                        String.format("Component %s already exists in %s with Id %d.",
                                component2.getClass().getSimpleName(),
                                this.getClass().getSimpleName(),
                                component2.getId()));
            }
        }
        this.components.add(component);
    }

    @Override
    public Component removeComponent(String componentType) {
        Component component = this.components.stream()
                .filter(c -> c.getClass().getSimpleName().equals(componentType))
                .findFirst().orElse(null);

        if (this.components.isEmpty() || component == null) {
            throw new IllegalArgumentException(
                    String.format("Component %s does not exist in %s with Id %d.",
                            componentType, this.getClass().getSimpleName(), this.getId()));
        }
        this.components.remove(component);
        return component;
    }

    @Override
    public void addPeripheral(Peripheral peripheral) {
        for (Peripheral peripheral1 : this.peripherals) {
            if (peripheral1.getClass().getSimpleName().equals(peripheral.getClass().getSimpleName())) {
                throw new IllegalArgumentException(
                        String.format("Peripheral %s already exists in %s with Id %d.",
                                peripheral1.getClass().getSimpleName(),
                                this.getClass().getSimpleName(),
                                peripheral1.getId()));
            }
        }
        this.peripherals.add(peripheral);
    }

    @Override
    public Peripheral removePeripheral(String peripheralType) {
        Peripheral toRemove = this.peripherals.stream()
                .filter(c -> c.getClass().getSimpleName().equals(peripheralType))
                .findFirst().orElse(null);

        if (this.peripherals.isEmpty() || toRemove == null) {
            throw new IllegalArgumentException(
                    String.format("Peripheral %s does not exist in %s with Id %d.",
                            peripheralType, this.getClass().getSimpleName(), this.getId()));
        }
        this.peripherals.remove(toRemove);
        return toRemove;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb
                .append
                        (String.format("Overall Performance: %.2f. Price: %.2f - %s: %s %s (Id: %d)",
                                this.getOverallPerformance(), this.getPrice(),
                                this.getClass().getSimpleName(), this.getManufacturer(), this.getModel(), this.getId()));
        sb.append(String.format(" Components (%d):", this.components.size()))
                .append(System.lineSeparator());
        for (Component component : this.getComponents()) {
            sb.append(String.format(" %s", component)).append(System.lineSeparator());
        }
        sb.append(String.format(" Peripherals (%d); ", this.peripherals.size()));
        double average =
                this.peripherals.stream().mapToDouble(Product::getOverallPerformance).average().orElse(0.00);
        sb.append(String.format("Average Overall Performance (%.2f):", average)).append(System.lineSeparator());
        for (Peripheral peripheral : this.peripherals) {
            sb.append(String.format(" %s", peripheral)).append(System.lineSeparator());
        }
        return sb.toString();
    }
}
