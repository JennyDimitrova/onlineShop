package onlineShop.core;

import onlineShop.core.interfaces.Controller;
import onlineShop.models.products.Product;
import onlineShop.models.products.components.*;
import onlineShop.models.products.computers.Computer;
import onlineShop.models.products.computers.DesktopComputer;
import onlineShop.models.products.computers.Laptop;
import onlineShop.models.products.peripherals.*;

import java.util.ArrayList;
import java.util.List;

public class ControllerImpl implements Controller {
    private List<Computer> computers;
    private List<Component> components;
    private List<Peripheral> peripherals;

    public ControllerImpl() {
        this.computers = new ArrayList<>();
        this.components = new ArrayList<>();
        this.peripherals = new ArrayList<>();
    }

    @Override
    public String addComputer(String computerType, int id, String manufacturer, String model, double price) {
        for (Computer computer : this.computers) {
            if (computer.getId() == id) {
                throw new IllegalArgumentException("Computer with this id already exists.");
            }
        }
        Computer computer;
        if (computerType.equals("DesktopComputer")) {
            computer = new DesktopComputer(id, manufacturer, model, price);
        } else if (computerType.equals("Laptop")) {
            computer = new Laptop(id, manufacturer, model, price);
        } else {
            throw new IllegalArgumentException("Computer type is invalid.");
        }
        this.computers.add(computer);
        return String.format("Computer with id %d added successfully.", id);
    }

    @Override
    public String addPeripheral(int computerId, int id, String peripheralType, String manufacturer, String model, double price, double overallPerformance, String connectionType) {
        Peripheral toAdd;
        Computer computer = this.computers.stream()
                .filter(c -> c.getId() == computerId)
                .findFirst().orElse(null);
        for (Peripheral peripheral : peripherals) {
            if (peripheral.getId() == id) {
                throw new IllegalArgumentException("Peripheral with this id already exists.");
            }
        }
        switch (peripheralType) {
            case "Headset":
                toAdd = new Headset(id, manufacturer, model, price, overallPerformance, connectionType);
                break;
            case "Keyboard":
                toAdd = new Keyboard(id, manufacturer, model, price, overallPerformance, connectionType);
                break;
            case "Monitor":
                toAdd = new Monitor(id, manufacturer, model, price, overallPerformance, connectionType);
                break;
            case "Mouse":
                toAdd = new Mouse(id, manufacturer, model, price, overallPerformance, connectionType);
                break;
            default:
                throw new IllegalArgumentException("Peripheral type is invalid.");
        }

        this.peripherals.add(toAdd);
        if (computer != null) {
            computer.addPeripheral(toAdd);
        }

        return String.format("Peripheral %s with id %s added successfully in computer with id %s.",
                peripheralType, id, computerId);
    }


    @Override
    public String removePeripheral(String peripheralType, int computerId) {
        Peripheral peripheral = null;
        Computer computer = this.computers.stream()
                .filter(c ->c.getId() == computerId)
                .findFirst().orElse(null);
        if (computer != null) {
            peripheral = computer.removePeripheral(peripheralType);
        }
        this.peripherals.remove(peripheral);
        assert peripheral != null;
        return String.format("Successfully removed %s with id %d.", peripheralType, peripheral.getId());
    }

    @Override
    public String addComponent(int computerId, int id, String componentType, String manufacturer, String model, double price, double overallPerformance, int generation) {
        Computer computer = this.computers.
                stream().filter(computer1 -> computer1.getId() == computerId).findFirst().orElse(null);

        for (Component component : this.components) {
            if (component.getId() == id) {
                throw new IllegalArgumentException("Component with this id already exists.");
            }
        }

        Component component;
        switch (componentType) {
            case "CentralProcessingUnit":
                component = new CentralProcessingUnit(id, manufacturer, model, price, overallPerformance, generation);
                break;
            case "Motherboard":
                component = new Motherboard(id, manufacturer, model, price, overallPerformance, generation);
                break;
            case "PowerSupply":
                component = new PowerSupply(id, manufacturer, model, price, overallPerformance, generation);
                break;
            case "RandomAccessMemory":
                component = new RandomAccessMemory(id, manufacturer, model, price, overallPerformance, generation);
                break;
            case "SolidStateDrive":
                component = new SolidStateDrive(id, manufacturer, model, price, overallPerformance, generation);
                break;
            case "VideoCard":
                component = new VideoCard(id, manufacturer, model, price, overallPerformance, generation);
                break;
            default:
                throw new IllegalArgumentException("Component type is invalid.");
        }
        if (computer != null) {
            this.components.add(component);
            computer.addComponent(component);
        }

        return String.format("Component %s with id %d added successfully in computer with id %d.",
                componentType, id, computerId);
    }

    @Override
    public String removeComponent(String componentType, int computerId) {
        Component component = null;
        Computer computer = this.computers.stream()
                .filter(c -> c.getId() == computerId).findFirst().orElse(null);
        if (computer != null) {
            component =
                    computer.getComponents().stream()
                            .filter(com -> com.getClass().getSimpleName().equals(componentType))
                            .findFirst().orElse(null);
            computer.removeComponent(componentType);
        }

        this.components.remove(component);
        return String.format("Successfully removed %s with id %d.",
                componentType, computerId);
    }

    @Override
    public String buyComputer(int id) {
        String result = "";
        Computer computer = this.computers.stream()
                .filter(c -> c.getId() == id)
                .findAny().orElse(null);
        if (computer != null) {
            this.computers.remove(computer);
            result  = computer.toString();
        }
        return result;
    }

    @Override
    public String BuyBestComputer(double budget) {
        String result = "";
        Computer best = this.computers.stream()
                .filter(c -> c.getOverallPerformance() <= budget)
                .findFirst().orElse(null);
        if (best == null) {
            result = String.format("Can't buy a computer with a budget of $%.2f.", budget);
        } else {
            result = best.toString();
            this.computers.remove(best);
        }

        return result;
    }

    @Override
    public String getComputerData(int id) {
        return null;
    }
}
