package onlineShop.core;

import onlineShop.core.interfaces.Engine;

public class EngineImpl implements Engine {
    @Override
    public void run() {

    }
}
